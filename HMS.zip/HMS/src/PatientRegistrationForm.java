import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class PatientRegistrationForm extends JFrame {

    private JTextField nameField;
    private JTextField addressField;
    private JTextField phoneNumberField;
    private JTextField emailField;
    private JComboBox<String> doctorComboBox;
    private JComboBox<String> timingComboBox;
    private JButton submitButton;
    private JButton backButton;

    private MenuPage menuPage;

    public PatientRegistrationForm(MenuPage menuPage) {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Appointment Booking");

        this.menuPage = menuPage;

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2, 10, 10)); // Adjusted spacing between components

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();

        JLabel addressLabel = new JLabel("City:");
        addressField = new JTextField();

        JLabel phoneNumberLabel = new JLabel("Phone Number:");
        phoneNumberField = new JTextField();

        JLabel emailLabel = new JLabel("Email ID:");
        emailField = new JTextField();

        JLabel doctorLabel = new JLabel("Select Doctor:");
        String[] doctors = {"Dr. Shyam", "Dr. Karthik", "Dr. Fawaz", "Dr. Navtej", "Dr. Murali", "Dr. Adithya", "Dr. Koushik", "Dr. Sriya", "Dr. Pearl"};
        doctorComboBox = new JComboBox<>(doctors);

        JLabel timingLabel = new JLabel("Select Timing:");
        String[] timings = {"10:00 AM", "11:00 AM", "12:00 PM", "2:00 PM", "3:00 PM", "4:00PM", "5:00 PM"};
        timingComboBox = new JComboBox<>(timings);

        submitButton = createStyledButton("Submit");
        backButton = createStyledButton("Back");

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(addressLabel);
        panel.add(addressField);
        panel.add(phoneNumberLabel);
        panel.add(phoneNumberField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(doctorLabel);
        panel.add(doctorComboBox);
        panel.add(timingLabel);
        panel.add(timingComboBox);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(submitButton);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(backButton);

        add(panel);
        setSize(400, 350);
        setLocationRelativeTo(null);
    }

    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(59, 89, 182));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(59, 89, 182), 2));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (label.equals("Submit")) {
                    submitPatientDetails();
                } else if (label.equals("Back")) {
                    goBackToMenuPage();
                }
            }
        });
        return button;
    }

    private void submitPatientDetails() {
        String name = nameField.getText();
        String address = addressField.getText();
        String phoneNumber = phoneNumberField.getText();
        String email = emailField.getText();
        String selectedDoctor = (String) doctorComboBox.getSelectedItem();
        String selectedTiming = (String) timingComboBox.getSelectedItem();

        if (name.isEmpty() || address.isEmpty() || phoneNumber.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Generate a random patient ID
        String patientId = generatePatientId();

        // Write patient details to a file
        writePatientToFile(patientId, name, address, phoneNumber, email, selectedDoctor, selectedTiming);

        JOptionPane.showMessageDialog(this, "Patient details submitted successfully\nPatient ID: " + patientId, "Success", JOptionPane.INFORMATION_MESSAGE);

        // Update the MenuPage with the patient details
        menuPage.addPatientDetails(new Patient(patientId, name, address, phoneNumber, email));

        // Close the current form and open the MenuPage
        dispose();
        menuPage.setVisible(true);
    }

    private void goBackToMenuPage() {
        this.dispose();
        menuPage.setVisible(true);
    }

    private void writePatientToFile(String patientId, String name, String address, String phoneNumber,
                                    String email, String selectedDoctor, String selectedTiming) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("patient_details.txt", true))) {
            writer.write(patientId + "," + name + "," + address + "," + phoneNumber + "," +
                    email + "," + selectedDoctor + "," + selectedTiming);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String generatePatientId() {
        String prefix = "P";
        int randomNumber = new Random().nextInt(1000);
        return prefix + randomNumber;
    }
}
