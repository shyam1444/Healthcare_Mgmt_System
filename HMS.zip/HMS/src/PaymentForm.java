import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PaymentForm extends JFrame {

    private JTextField patientIdField;
    private JTextField discountCouponField;
    private JButton calculatePaymentButton;
    private JButton printReceiptButton;
    private JButton backButton;

    private MenuPage menuPage;

    public PaymentForm(MenuPage menuPage) {
        this.menuPage = menuPage;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Make Payment");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10)); // Added some spacing between components

        JLabel patientIdLabel = new JLabel("Enter Patient ID:");
        patientIdField = new JTextField();

        JLabel discountCouponLabel = new JLabel("Enter Discount Coupon:");
        discountCouponField = new JTextField();

        calculatePaymentButton = createStyledButton("Calculate Payment");
        calculatePaymentButton.addActionListener(e -> calculatePayment());

        printReceiptButton = createStyledButton("Print Receipt");
        printReceiptButton.addActionListener(e -> printReceipt());

        backButton = createStyledButton("Back");
        backButton.addActionListener(e -> goBackToMenuPage());

        panel.add(patientIdLabel);
        panel.add(patientIdField);
        panel.add(discountCouponLabel);
        panel.add(discountCouponField);
        panel.add(new JLabel());
        panel.add(calculatePaymentButton);
        panel.add(new JLabel());
        panel.add(printReceiptButton);
        panel.add(new JLabel());
        panel.add(backButton);

        add(panel);
        setSize(400, 300);
        setLocationRelativeTo(null);
    }

    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 123, 255)); // Blue color
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255), 2));
        return button;
    }

    private void calculatePayment() {
        String patientId = patientIdField.getText().trim();
        String discountCoupon = discountCouponField.getText().trim();

        if (!patientExists(patientId)) {
            JOptionPane.showMessageDialog(this, "Invalid Patient ID. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate discount coupon
        if (!isValidDiscountCoupon(discountCoupon)) {
            JOptionPane.showMessageDialog(this, "Invalid Discount Coupon. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double appointmentCost = 150;
        double totalPayment = appointmentCost;

        // Apply discount
        totalPayment -= getDiscountAmount(discountCoupon);

        String invoiceDetails = "Patient ID: " + patientId +
                "\nAppointment Cost: Rs" + appointmentCost +
                "\nTotal Payment: Rs" + totalPayment;

        JOptionPane.showMessageDialog(this, invoiceDetails, "Invoice", JOptionPane.INFORMATION_MESSAGE);
    }

    private void printReceipt() {
        // Display a processing message
        JOptionPane.showMessageDialog(this, "Processing... Printing Receipt", "Processing", JOptionPane.INFORMATION_MESSAGE);

        // Dummy implementation, replace with your actual printing logic
        System.out.println("Printing Receipt...");

        // Display success message
        JOptionPane.showMessageDialog(this, "Receipt Printed Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void goBackToMenuPage() {
        this.dispose();
        menuPage.setVisible(true);
    }

    private boolean patientExists(String patientId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("patient_details.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].equals(patientId)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean isValidDiscountCoupon(String discountCoupon) {
        // Implement your discount coupon validation logic here
        // For now, let's assume any non-empty string is a valid coupon
        return !discountCoupon.isEmpty();
    }

    private double getDiscountAmount(String discountCoupon) {
        // Implement your discount calculation logic here
        // For now, let's assume a fixed discount amount of Rs 40.0
        return 40.0;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PaymentForm(new MenuPage(new LoginPage())).setVisible(true));
    }
}