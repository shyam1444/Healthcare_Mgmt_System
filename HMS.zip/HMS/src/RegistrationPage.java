import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RegistrationPage extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JTextField captchaField;
    private JLabel captchaLabel;
    private JButton registerButton;

    private Map<String, String> userDatabase;

    public RegistrationPage() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("STAR HOSPITALS USER REGISTRATION");

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        JLabel captchaTextLabel = new JLabel("Captcha:");
        captchaLabel = new JLabel(generateCaptcha());
        captchaLabel.setFont(new Font("Arial", Font.PLAIN, 18)); // Increase font size

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        confirmPasswordField = new JPasswordField();
        captchaField = new JTextField();

        registerButton = createStyledButton("Register");

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10)); // Adjust spacing between rows and columns
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add padding

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(confirmPasswordLabel);
        panel.add(confirmPasswordField);
        panel.add(captchaTextLabel);
        panel.add(captchaField);
        panel.add(captchaLabel); // Display captcha here
        panel.add(registerButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panel, BorderLayout.CENTER);

        userDatabase = new HashMap<>();

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });

        setSize(400, 250);
        setLocationRelativeTo(null);
    }

    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 123, 255));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255), 2));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        return button;
    }

    private void registerUser() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String enteredCaptcha = captchaField.getText().trim();
        String actualCaptcha = captchaLabel.getText();

        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || enteredCaptcha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match. Please re-enter passwords.", "Error", JOptionPane.ERROR_MESSAGE);
            clearFields();
            return;
        }

        if (!enteredCaptcha.equalsIgnoreCase(actualCaptcha)) {
            JOptionPane.showMessageDialog(this, "Captcha verification failed. Please enter the correct captcha.", "Error", JOptionPane.ERROR_MESSAGE);
            clearFields();
            return;
        }

        if (userDatabase.containsKey(username)) {
            JOptionPane.showMessageDialog(this, "Username already registered. Please choose a different username.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // Store the username and hashed password in a text file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("userDatabase.txt", true))) {
                String hashedPassword = hashPassword(password);
                writer.write(username + "," + hashedPassword);
                writer.newLine();
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error storing user credentials.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            userDatabase.put(username, password);
            JOptionPane.showMessageDialog(this, "User registered successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();

            // Open the login page after successful registration
            openLoginPage();
        }
    }

    private void openLoginPage() {
        LoginPage loginPage = new LoginPage();
        loginPage.setVisible(true);
        this.dispose(); // Close the registration page
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        captchaField.setText("");
        captchaLabel.setText(generateCaptcha());
    }

    private String generateCaptcha() {
        // Generate a simple random 4-character captcha
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder captcha = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < 4; i++) {
            captcha.append(chars.charAt(random.nextInt(chars.length())));
        }

        return captcha.toString();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(password.getBytes());
            byte[] digest = md.digest();
            return bytesToHex(digest);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new RegistrationPage().setVisible(true);
            }
        });
    }
}
