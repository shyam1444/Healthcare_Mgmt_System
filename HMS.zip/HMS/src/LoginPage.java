import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginPage extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JButton exitButton; // Added Exit button

    private MenuPage menuPage;
    private RegistrationPage registrationPage;

    public LoginPage() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("STAR HOSPITALS");

        JLabel welcomeLabel = new JLabel("   WELCOME TO STAR HOSPITALS   ");
        welcomeLabel.setForeground(Color.BLUE);
        welcomeLabel.setBounds(50, 20, 300, 30);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.BLUE);
        usernameLabel.setBounds(50, 70, 80, 30);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.BLUE);
        passwordLabel.setBounds(50, 110, 80, 30);

        usernameField = new JTextField();
        usernameField.setBounds(140, 70, 150, 30);

        passwordField = new JPasswordField();
        passwordField.setBounds(140, 110, 150, 30);

        loginButton = new JButton("Login");
        loginButton.setBounds(80, 160, 80, 30);

        registerButton = new JButton("Register");
        registerButton.setBounds(180, 160, 100, 30);

        exitButton = new JButton("Exit");
        exitButton.setBounds(290, 160, 80, 30);

        getContentPane().setLayout(null);
        getContentPane().add(welcomeLabel);
        getContentPane().add(usernameLabel);
        getContentPane().add(passwordLabel);
        getContentPane().add(usernameField);
        getContentPane().add(passwordField);
        getContentPane().add(loginButton);
        getContentPane().add(registerButton);
        getContentPane().add(exitButton); // Added Exit button

        setSize(400, 250);
        setLocationRelativeTo(null);

        menuPage = new MenuPage(this);
        registrationPage = new RegistrationPage();

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performLogin();
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openRegistrationPage();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitApplication();
            }
        });
    }

    private void performLogin() {
        // Read stored credentials from the file
        String enteredUsername = usernameField.getText();
        String enteredPassword = new String(passwordField.getPassword());

        if (checkCredentials(enteredUsername, enteredPassword)) {
            openMenuPage();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials. Please try again.", "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean checkCredentials(String enteredUsername, String enteredPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader("userDatabase.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String storedUsername = parts[0].trim();
                    String storedHashedPassword = parts[1].trim();
                    String enteredHashedPassword = hashPassword(enteredPassword);

                    if (storedUsername.equals(enteredUsername) && storedHashedPassword.equals(enteredHashedPassword)) {
                        return true; // Credentials match
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false; // No matching credentials found
    }

    private void openMenuPage() {
        this.setVisible(false);
        menuPage.setVisible(true);
    }

    private void openRegistrationPage() {
        this.setVisible(false);
        registrationPage.setVisible(true);
    }

    private void exitApplication() {
        System.exit(0);
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(password.getBytes());
            byte[] digest = md.digest();
            return bytesToHex(digest);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }
}
