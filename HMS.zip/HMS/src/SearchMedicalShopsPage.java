import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchMedicalShopsPage extends JFrame {

    private JButton searchButton;
    private JButton backButton;
    private JTextField searchField;
    private JTextArea resultTextArea;

    public SearchMedicalShopsPage() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Search Medical Shops");

        searchButton = createStyledButton("Search");
        backButton = createStyledButton("Back");
        searchField = new JTextField(20); // Set preferred width for searchField
        resultTextArea = new JTextArea(10, 30); // Set preferred rows and columns for resultTextArea
        resultTextArea.setEditable(false);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(searchField, BorderLayout.CENTER);
        panel.add(searchButton, BorderLayout.EAST);
        panel.add(backButton, BorderLayout.WEST);

        // Add equal horizontal spacing between components
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(new JScrollPane(resultTextArea), BorderLayout.CENTER);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchMedicalShops();
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBackToMainMenu();
            }
        });

        pack(); // Adjust the frame size based on components
        setLocationRelativeTo(null);
    }

    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(59, 89, 182));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        return button;
    }

    private void searchMedicalShops() {
        // Dummy implementation, replace with your logic to search for medical shops
        String searchTerm = searchField.getText().trim();

        // Check if the search term matches any of the displayed data
        boolean matchFound = false;
        StringBuilder resultText = new StringBuilder("Search Results for '" + searchTerm + "':\n");
        for (int i = 1; i <= 20; i++) {
            String shopName = i + ". " + getMedicalShopName(i);
            if (shopName.toLowerCase().contains(searchTerm.toLowerCase())) {
                resultText.append(shopName).append("\n");
                matchFound = true;
            }
        }

        // Display the search results or "Not available" message
        if (matchFound) {
            resultTextArea.setText(resultText.toString());
        } else {
            resultTextArea.setText("No matching results for '" + searchTerm + "'.");
        }
    }

    private String getMedicalShopName(int index) {
        switch (index) {
            case 1:
                return "Health Haven Pharmacy - Mumbai, Maharashtra";
            case 2:
                return "Rainbow Remedies - Bangalore, Karnataka";
            case 3:
                return "Wellcare Drugstore - Delhi, NCR";
            case 4:
                return "Medico Mart - Hyderabad, Telangana";
            case 5:
                return "Cure Corner Pharmacy - Chennai, Tamil Nadu";
            case 6:
                return "Sunshine Pharmacy - Kolkata, West Bengal";
            case 7:
                return "Nature's Remedy Pharmacy - Pune, Maharashtra";
            case 8:
                return "Apex Medical Solutions - Ahmedabad, Gujarat";
            case 9:
                return "Serene Health Hub - Jaipur, Rajasthan";
            case 10:
                return "MedPlus Pharmacy - Lucknow, Uttar Pradesh";
            case 11:
                return "Starlight Drug Center - Chandigarh";
            case 12:
                return "Wellness World Pharmacy - Bhopal, Madhya Pradesh";
            case 13:
                return "Green Leaf Apothecary - Kochi, Kerala";
            case 14:
                return "Harmony Health Store - Indore, Madhya Pradesh";
            case 15:
                return "MediSavers Pharmacy - Visakhapatnam, Andhra Pradesh";
            case 16:
                return "Prime Care Pharmacy - Surat, Gujarat";
            case 17:
                return "Blissful Remedies - Nagpur, Maharashtra";
            case 18:
                return "Swift Aid Pharmacy - Kanpur, Uttar Pradesh";
            case 19:
                return "Sunrise Medicals - Coimbatore, Tamil Nadu";
            case 20:
                return "Crystal Clear Chemists - Thane, Maharashtra";
            default:
                return "";
        }
    }

    private void goBackToMainMenu() {
        this.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new SearchMedicalShopsPage().setVisible(true);
            }
        });
    }
}