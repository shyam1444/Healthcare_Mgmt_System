import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class PatientDetailsDisplayForm extends JFrame {

    private JTextField patientIdField;
    private JButton displayDetailsButton;
    private JButton backButton;

    private double totalCost; // Added total cost variable

    public PatientDetailsDisplayForm() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Patient Details Display");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel patientIdLabel = new JLabel("Enter Patient ID:");
        patientIdField = new JTextField();

        displayDetailsButton = createStyledButton("Display Details");
        backButton = createStyledButton("Back");

        this.totalCost = totalCost;

        panel.add(patientIdLabel);
        panel.add(patientIdField);
        panel.add(displayDetailsButton);
        panel.add(backButton);

        // Add a label to display total cost

        displayDetailsButton.addActionListener(e -> displayPatientDetails());

        backButton.addActionListener(e -> goBackToMenuPage());

        add(panel);
        setSize(400, 200);
        setLocationRelativeTo(null);
    }

    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 123, 255)); // Blue color
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255), 2));
        return button;
    }

    private void displayPatientDetails() {
        String patientId = patientIdField.getText().trim();

        // Check if the patient ID exists
        if (!patientExists(patientId)) {
            JOptionPane.showMessageDialog(this, "Invalid Patient ID. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Retrieve patient details and medicine details
        String patientDetails = getPatientDetails(patientId);
        String medicineDetails = getMedicineDetails(patientId);

        // Display patient details and medicine details
        String details = patientDetails + "\n" + medicineDetails;
        JOptionPane.showMessageDialog(this, details, "Patient Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private String getPatientDetails(String patientId) {
        StringBuilder details = new StringBuilder("\n");

        try (BufferedReader reader = new BufferedReader(new FileReader("patient_details.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].equals(patientId)) {
                    details.append("Patient ID: ").append(parts[0]).append("\n")
                            .append("Name: ").append(parts[1]).append("\n")
                            .append("City: ").append(parts[2]).append("\n")
                            .append("Phone Number: ").append(parts[3]).append("\n")
                            .append("Email: ").append(parts[4]).append("\n")
                            .append("Doctor: ").append(parts[5]).append("\n")
                            .append("Timing: ").append(parts[6]).append("\n");
                    return details.toString();  // Return details if patient found
                }
            }
            // Patient not found
            details.append("Patient with ID ").append(patientId).append(" not found.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return details.toString();
    }

    private String getMedicineDetails(String patientId) {
        StringBuilder details = new StringBuilder("Medicine Details:\n");

        try (BufferedReader reader = new BufferedReader(new FileReader("medicine_bookings.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].equals(patientId)) {
                    details.append("Medicine: ").append(parts[1]).append("\nQuantity: ").append(parts[2]).append("\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (details.toString().equals("Medicine Details:\n")) {
            details.append("No medicine details found for the patient.");
        }

        return details.toString();
    }

    private boolean patientExists(String patientId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("patient_details.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].equals(patientId)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void goBackToMenuPage() {
        this.dispose();
        MenuPage menuPage = new MenuPage(new LoginPage()); // You might need to adjust this instantiation
        menuPage.setVisible(true);
    }

    public static void main(String[] args) {
        List<String> selectedMedicines = null;
        SwingUtilities.invokeLater(() -> new PatientDetailsDisplayForm().setVisible(true));
    }
}
