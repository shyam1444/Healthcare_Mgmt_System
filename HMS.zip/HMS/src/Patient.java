import java.util.List;

public class Patient {
    private String patientId;
    private String name;
    private String address;
    private String phoneNumber;
    private String email;

    public Patient(String patientId, String name, String address, String phoneNumber, String email) {
        this.patientId = patientId;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public static Patient getPatientDetails(String patientId, List<Patient> patientList) {
        for (Patient patient : patientList) {
            if (patient.getPatientId().equals(patientId)) {
                return patient;
            }
        }
        return null; // Patient not found
    }
}
