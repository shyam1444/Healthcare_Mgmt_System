import javax.swing.*;
import java.awt.*;
import java.io.*;

public class MedicineBookingForm extends JFrame {

    private JTextField patientIdField;
    private JComboBox<String> medicineComboBox;
    private JTextField quantityField;
    private JButton bookMedicineButton;
    private JButton backButton;

    private MenuPage menuPage;

    public MedicineBookingForm(MenuPage menuPage) {
        this.menuPage = menuPage;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Medicine Booking");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10)); // Added some spacing between components

        JLabel patientIdLabel = new JLabel("Patient ID:");
        patientIdField = new JTextField();

        JLabel medicineLabel = new JLabel("Select Medicine:");
        String[] medicines = {
                "Paracetamol", "Aspirin", "Antibiotic", "Ibuprofen", "Acetaminophen",
                "Ciprofloxacin", "Amoxicillin", "Lisinopril", "Metformin", "Amlodipine",
                "Atorvastatin", "Simvastatin", "Levothyroxine", "Omeprazole", "Gabapentin",
                "Hydrochlorothiazide", "Metoprolol", "Losartan", "Warfarin", "Furosemide"
        };
        medicineComboBox = new JComboBox<>(medicines);

        JLabel quantityLabel = new JLabel("Enter Quantity:");
        quantityField = new JTextField();

        bookMedicineButton = createStyledButton("Book Medicine");
        bookMedicineButton.addActionListener(e -> bookMedicine());

        backButton = createStyledButton("Back");
        backButton.addActionListener(e -> goBackToMenuPage());

        panel.add(patientIdLabel);
        panel.add(patientIdField);
        panel.add(medicineLabel);
        panel.add(medicineComboBox);
        panel.add(quantityLabel);
        panel.add(quantityField);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(bookMedicineButton);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(backButton);

        add(panel);
        setSize(400, 300);
        setLocationRelativeTo(null);
    }

    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 123, 255)); // Blue color
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255), 2));
        return button;
    }

    private void bookMedicine() {
        String patientId = patientIdField.getText().trim();
        String selectedMedicine = (String) medicineComboBox.getSelectedItem();
        int quantity = Integer.parseInt(quantityField.getText().trim());

        if (!patientExists(patientId)) {
            JOptionPane.showMessageDialog(this, "Invalid Patient ID. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double medicineCost = getMedicineCost(selectedMedicine);
        double totalCost = medicineCost * quantity;

        // Update medicine details in the file
        updateMedicineDetails(patientId, selectedMedicine, quantity);

        menuPage.addMedicineBooking(this);

        JOptionPane.showMessageDialog(this, "Medicine booked successfully!\nPatient ID: " + patientId +
                "\nMedicine: " + selectedMedicine + "\nQuantity: " + quantity + "\nTotal Cost: Rs" + totalCost);

        goBackToMenuPage(); // Redirect to MenuPage
    }

    private void updateMedicineDetails(String patientId, String medicine, int quantity) {
        // Append the new medicine details to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("medicine_bookings.txt", true))) {
            writer.write(patientId + "," + medicine + "," + quantity);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void goBackToMenuPage() {
        this.dispose();
        menuPage.setVisible(true);
    }

    private boolean patientExists(String patientId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("patient_details.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].equals(patientId)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private double getMedicineCost(String medicine) {
        switch (medicine) {
            case "Paracetamol":
                return 100.0;
            case "Aspirin":
                return 150.0;
            case "Antibiotic":
                return 200.0;
            case "Ibuprofen":
                return 120.0;
            case "Ciprofloxacin":
                return 180.0;
            case "Lisinopril":
                return 220.0;
            case "Atorvastatin":
                return 250.0;
            case "Amlodipine":
                return 210.0;
            case "Metformin":
                return 130.0;
            case "Omeprazole":
                return 160.0;
            case "Gabapentin":
                return 190.0;
            case "Hydrochlorothiazide":
                return 170.0;
            case "Simvastatin":
                return 240.0;
            case "Metoprolol":
                return 200.0;
            case "Losartan":
                return 230.0;
            case "Azithromycin":
                return 140.0;
            case "Doxycycline":
                return 160.0;
            case "Warfarin":
                return 180.0;
            case "Insulin":
                return 250.0;
            case "Morphine":
                return 300.0;
            default:
                return 0.0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MedicineBookingForm(new MenuPage(new LoginPage())).setVisible(true));
    }
}
