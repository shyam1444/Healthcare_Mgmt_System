import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MenuPage extends JFrame {

    private List<Patient> patientList = new ArrayList<>();
    private List<MedicineBookingForm> medicineBookingList = new ArrayList<>();

    private LoginPage loginPage;

    private JButton searchMedicalShopsButton;

    public MenuPage(LoginPage loginPage) {
        this.loginPage = loginPage;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("STAR HOSPITALS");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1));

        JButton patientRegistrationButton = createButton("Book an Appointment");
        JButton medicineBookingButton = createButton("Pre-Order Medicines");
        JButton makePaymentButton = createButton("Payment");
        JButton displayPatientDetailsButton = createButton("Generate Invoice Details");
        searchMedicalShopsButton = createButton("Search Medical Shops");
        JButton backButton = createButton("Back");

        panel.add(patientRegistrationButton);
        panel.add(medicineBookingButton);
        panel.add(makePaymentButton);
        panel.add(displayPatientDetailsButton);
        panel.add(searchMedicalShopsButton);
        panel.add(backButton);

        add(panel);
        setSize(300, 300);
        setLocationRelativeTo(null);
    }

    private JButton createButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.BLUE);
        button.addActionListener(e -> handleButtonClick(label));
        return button;
    }

    private void handleButtonClick(String buttonLabel) {
        switch (buttonLabel) {
            case "Book an Appointment":
                openPatientRegistrationForm();
                break;
            case "Pre-Order Medicines":
                openMedicineBookingForm();
                break;
            case "Payment":
                openPaymentForm();
                break;
            case "Generate Invoice Details":
                openPatientDetailsDisplayForm();
                break;
            case "Search Medical Shops":
                openSearchMedicalShopsPage();
                break;
            case "Back":
                goBackToLoginPage();
                break;
        }
    }

    private void openPatientRegistrationForm() {
        PatientRegistrationForm patientRegistrationForm = new PatientRegistrationForm(this);
        patientRegistrationForm.setVisible(true);
        this.setVisible(false);
    }

    private void openMedicineBookingForm() {
        MedicineBookingForm medicineBookingForm = new MedicineBookingForm(this);
        medicineBookingForm.setVisible(true);
        this.setVisible(false);
    }

    private void openPaymentForm() {
        PaymentForm paymentForm = new PaymentForm(this);
        paymentForm.setVisible(true);
        this.setVisible(false);
    }

    private void openPatientDetailsDisplayForm() {
        PatientDetailsDisplayForm detailsDisplayForm = new PatientDetailsDisplayForm();
        detailsDisplayForm.setVisible(true);
    }

    private void openSearchMedicalShopsPage() {
        SearchMedicalShopsPage searchMedicalShopsPage = new SearchMedicalShopsPage();
        searchMedicalShopsPage.setVisible(true);
    }

    private void goBackToLoginPage() {
        this.setVisible(false);
        loginPage.setVisible(true);
    }

    public LoginPage getLoginPage() {
        return loginPage;
    }

    public void addPatientDetails(Patient patient) {
        patientList.add(patient);
    }

    public void addMedicineBooking(MedicineBookingForm medicineBookingForm) {
        medicineBookingList.add(medicineBookingForm);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPage(new LoginPage()).setVisible(true));
    }
}
